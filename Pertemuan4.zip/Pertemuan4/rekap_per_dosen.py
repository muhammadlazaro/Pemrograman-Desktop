import pandas as pd
from reportlab.lib.pagesizes import A4
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer, PageBreak, Image
from reportlab.lib import colors
from reportlab.lib.colors import HexColor
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
import re


# Mapping nilai teks ke angka
nilai_map = {
    "Sangat Setuju": 4,
    "Setuju": 3,
    "Cukup Setuju": 2,
    "Tidak Setuju": 1
}

# Baca file CSV
df = pd.read_csv('results-survey514713.csv')

# Ganti nilai teks ke angka
pertanyaan_cols = [col for col in df.columns if col not in ["Response ID", "Sampaikan saran/masukan untuk dosen pengampu Bapak/Ibu\u00a0{TOKEN:ATTRIBUTE_1} pada Mata Kuliah\u00a0{TOKEN:ATTRIBUTE_2}\u00a0 ", "Nama Dosen", "Mata Kuliah"]]
df_num = df.copy()
for col in pertanyaan_cols:
    df_num[col] = df_num[col].map(nilai_map)

# Daftar aspek dan regex pencarian
aspek_map = {
    "Kompetensi Pedagogik": r"Pedagogik",
    "Kompetensi Profesional": r"Kompetensi Profesional",
    "Kepribadian Dosen": r"kepribadian",
    "Metode Pembelajaran": r"Metode pembelajaran",
    "Media Pembelajaran": r"media pembelajaran"
}

# Warna
BIRU_TUA = HexColor('#003366')
ABU_MUDA = colors.whitesmoke

# Style judul
judul_style = ParagraphStyle(
    'judul', fontSize=16, leading=20, alignment=1, textColor=BIRU_TUA, spaceAfter=8, fontName='Helvetica-Bold'
)
subjudul_style = ParagraphStyle(
    'subjudul', fontSize=12, leading=16, alignment=1, textColor=BIRU_TUA, spaceAfter=8, fontName='Helvetica-Bold'
)
wrap_style = ParagraphStyle('wrap', fontSize=9, leading=12)

header_style = ParagraphStyle(
    'header', fontSize=9, leading=11, alignment=1, textColor=colors.white, fontName='Helvetica-Bold'
)

# Siapkan PDF
pdf = SimpleDocTemplate("rekap_semua_dosen.pdf", pagesize=A4)
styles = getSampleStyleSheet()
elements = []

# Loop per dosen & mata kuliah
for idx, ((dosen, matkul), group) in enumerate(df_num.groupby(["Nama Dosen", "Mata Kuliah"])):
    logo_path = "LOGO PoltekSSN.png"
    logo_img = Image(logo_path, width=60, height=60)
    # Gabungkan judul, subjudul, nama dosen/matkul dalam satu Paragraph (pakai <br/> untuk ganti baris)
    header_text = (
        "<b>Evaluasi Dosen oleh Taruna</b><br/>"
        "Politeknik Siber dan Sandi Negara | Jurusan Kriptografi<br/>"
        "Semester Gasal T.A. 2024/2025<br/><br/>"
        f"<b>{dosen}</b><br/>{matkul}"
    )
    header_para = Paragraph(header_text, ParagraphStyle(
        'headertext', fontSize=12, leading=15, leftIndent=0, spaceAfter=0, textColor=BIRU_TUA, fontName='Helvetica-Bold'
    ))
    # Buat tabel header 2 kolom
    header_table = Table(
        [[logo_img, header_para]],
        colWidths=[70, 400],  # Atur lebar kolom sesuai kebutuhan
        hAlign='LEFT'
    )
    header_table.setStyle(TableStyle([
        ('VALIGN', (0,0), (-1,-1), 'TOP'),
        ('ALIGN', (0,0), (0,0), 'LEFT'),
        ('ALIGN', (1,0), (1,0), 'LEFT'),
        ('LEFTPADDING', (0,0), (-1,-1), 0),
        ('RIGHTPADDING', (0,0), (-1,-1), 0),
        ('TOPPADDING', (0,0), (-1,-1), 0),
        ('BOTTOMPADDING', (0,0), (-1,-1), 0),
    ]))
    elements.append(header_table)
    elements.append(Spacer(1, 12))
    rata_per_pertanyaan = group[pertanyaan_cols].mean().round(2)
    rata_kelas = df_num[pertanyaan_cols].mean().round(2)
    # Siapkan data tabel
    data = [
        [
            Paragraph("Aspek/Pertanyaan", header_style),
            Paragraph("Nilai", header_style),
            Paragraph("Nilai Rata-<br/>Rata Kelas", header_style)
        ]
    ]
    last_aspek = None
    for col in pertanyaan_cols:
        # Tentukan aspek
        aspek = None
        for aspek_name, aspek_regex in aspek_map.items():
            if re.search(aspek_regex, col, re.IGNORECASE):
                aspek = aspek_name
                break
        # Jika aspek berubah, tambahkan baris judul aspek
        if aspek and aspek != last_aspek:
            data.append([
                Paragraph(f"<b>{aspek}</b>", wrap_style), '', ''
            ])
            last_aspek = aspek
        # Ekstrak pertanyaan di dalam tanda []
        match = re.search(r"\[(.*?)\]$", col)
        if match:
            pertanyaan = match.group(1).strip()
        else:
            pertanyaan = col.strip()
        data.append([
            Paragraph(pertanyaan, wrap_style),
            rata_per_pertanyaan[col],
            rata_kelas[col]
        ])

    # Tabel
    table = Table(data, repeatRows=1, colWidths=[250, 60, 80])
    style = TableStyle([
        ('BACKGROUND', (0,0), (-1,0), BIRU_TUA),
        ('TEXTCOLOR', (0,0), (-1,0), colors.white),
        ('ALIGN', (0,0), (-1,0), 'CENTER'),  # Header center
        ('ALIGN', (0,1), (-1,-1), 'LEFT'),   # Isi kiri
        ('FONTNAME', (0,0), (-1,0), 'Helvetica-Bold'),
        ('FONTSIZE', (0,0), (-1,0), 9),
        ('FONTSIZE', (0,1), (-1,-1), 9),
        ('BOTTOMPADDING', (0,0), (-1,0), 8),
        ('BACKGROUND', (0,1), (-1,-1), ABU_MUDA),
        ('GRID', (0,0), (-1,-1), 0.5, BIRU_TUA),
    ])
    # Tebalkan baris aspek
    for i, row in enumerate(data):
        if row[1] == '' and row[2] == '':
            style.add('FONTNAME', (0,i), (0,i), 'Helvetica-Bold')
            style.add('FONTSIZE', (0,i), (0,i), 10)
            style.add('BACKGROUND', (0,i), (-1,i), colors.lightgrey)
    table.setStyle(style)
    elements.append(table)

    # Tambahkan saran/masukan dari taruna dalam bentuk tabel
    saran_col = "Sampaikan saran/masukan untuk dosen pengampu Bapak/Ibu\u00a0{TOKEN:ATTRIBUTE_1} pada Mata Kuliah\u00a0{TOKEN:ATTRIBUTE_2}\u00a0 "
    saran_list = group[saran_col].dropna().astype(str).tolist()
    if saran_list:
        elements.append(Spacer(1, 18))
        elements.append(Paragraph("<b>Saran/masukan dari Taruna</b>", ParagraphStyle('saransub', fontSize=12, spaceAfter=8, backColor=ABU_MUDA, textColor=BIRU_TUA)))
        # Buat data tabel saran
        saran_data = [["No", "Saran/Masukan"]]
        for i, saran in enumerate(saran_list, 1):
            saran_data.append([str(i), Paragraph(saran, wrap_style)])
        saran_table = Table(saran_data, colWidths=[30, 360])
        saran_style = TableStyle([
            ('BACKGROUND', (0,0), (-1,0), BIRU_TUA),
            ('TEXTCOLOR', (0,0), (-1,0), colors.white),
            ('ALIGN', (0,0), (0,-1), 'CENTER'),
            ('ALIGN', (1,0), (1,-1), 'LEFT'),
            ('FONTNAME', (0,0), (-1,0), 'Helvetica-Bold'),
            ('FONTSIZE', (0,0), (-1,-1), 10),
            ('BOTTOMPADDING', (0,0), (-1,0), 6),
            ('GRID', (0,0), (-1,-1), 0.5, BIRU_TUA),
        ])
        saran_table.setStyle(saran_style)
        elements.append(saran_table)

    # Tambahkan page break kecuali di akhir
    if idx < len(df_num.groupby(["Nama Dosen", "Mata Kuliah"])) - 1:
        elements.append(PageBreak())

pdf.build(elements)
print("PDF rekap seluruh dosen berhasil dibuat: rekap_semua_dosen.pdf")